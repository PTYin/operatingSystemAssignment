
# How to compile Linux 0.00 and boot it

## Compile Linux 0.00

Host:

    $ make boot-hd

Guest:

    $ cd examples/linux-0.00
    $ make

## Boot it

Host:

    $ make linux-0.00
