
1. [Linux 0.01](http://draconux.free.fr/os_dev/linux0.01_news.html)
  - [Kernel 0.01 Walkthrough](https://kernelnewbies.org/Kernel001WalkThrough)
  - [Linux 0.01 Github](https://github.com/liudonghua123/linux-0.01)
2. [Linux 0.99](https://github.com/freewilll/linux-evocation)
3. [x86/x64 Instructions](http://www.mouseos.com/x64/default.html)
4. [CS194-24: Advanced Operating Systems Structures and Implementation](https://people.eecs.berkeley.edu/~kubitron/cs194-24/index_overview.html)
5. [CS630 Qemu Lab: Advanced Microcomputer Programming](http://tinylab.org/cs630-qemu-lab)
